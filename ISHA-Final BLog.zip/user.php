<?php

$con = mysqli_connect('localhost','root');

if($con){
    echo "connection successful";
}
else{
    "no connection";
}
mysqli_select_db($con,'blog');

$fname = $_POST['fname'];
$lname = $_POST['lname']
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$message = $_POST['message'];

$query = "insert into blog(fname, lname, mobile, email, message)
values('$fname', '$lname', '$mobile', '$email', '$description')";

echo "$query";

mysqli_query($con, $query);
header('location:inex.php');
?>