<!DOCTYPE html>
<html lang="en">
    <head>
        
        <title>MY NEW BLOG</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <header>
            <a href="#" class="logo">My New Blog</a>
            <div class="menuToggle"></div>
        </header>
    <ul class="navigation">
        <li><a href="#home" onclick="toggleMenu();">Home</a></li>
        <li><a href="#about" onclick="toggleMenu();">About Us</a></li>
        <li><a href="#post"onclick="toggleMenu();">Latest Posts</a></li>
        <li><a href="#Contact" onclick="toggleMenu();">Contact Us</a></li>
    </ul>

    <!--Banner-->
    <section class="banner" id="home">
        <img src= "banner.jpeg" class="cover">
        <div class="contentBx">
           <h2>The Writing Room</h2> 
           <h4>Blog Website by Isha</h4>
           <a href="#about" class="btn">About Us</a>
        </div> 
    </section>
    <!--About Us-->
    <section class="about" id="about">
        <div class="title">
            <h2>About Us</h2>
        </div>
        <div class="contentBx">
            <div class="content">
                <p >Write a topic sentence summarizing the main idea of the paragraph. This is usually the first sentence of a paragraph and it sets the course for the rest of the paragraph. By reading the topic sentence, the reader knows that the rest of the paragraph will provide more information related to the main idea. For example: “One benefit of exercise is that it burns calories.” This lets the reader know that the following sentences in the paragraph will provide more information about this benefit.

                    Write sentences supporting the topic sentence using the information you gathered in your research. Choose the information that provides the strongest support for your topic sentence. For example, you might include a sentence with a statistic from an expert about the number of calories used during a half-hour walk. You might follow this with a sentence about the effect of burning calories on the person’s health. </p> </div>
              
                <div class="imgBx">
                <img src="img1.jpeg" class="coverr">
                </div>
                </div>
            </div>
    </section>
    
    <!-- Latest Blog Post-->
     <section class="post" id="post" >
         <div class="title">
             <h2>Latest Posts</h2>
             <p>The aural presentation converts the document to plain text and feed this to a screen reader (a program that reads all the characters on the screen).</p>
         </div>
         <div class="contentBx">
             <div class="postColoum" >
                 <div class="postBox">
    <div class="covereded">
                    <img class="covered" src="post1.jpg" >
                </div>
                  <div class="textBx">
                     <h3> The grid's total width has to be less than the container's width for the justify-content property to have any effect.</h3>
                     <a href="#" class="btn">Read More</a>
                    </div>
                 </div>
            
        
                <div class="postBox">
                   
                    <img src="post2.jpg" class="covered">
                    
                <div class="textBx">
                    <h3> The grid's total width has to be less than the container's width for the justify-content property to have any effect.</h3>
                    <a href="#" class="btn">Read More</a>
                </div>
                </div>
           
       
                <div class="postBox">
                   
                    <img src="post3.jpg" class="covered">
                    
                    <div class="textBx">
                    <h3> The grid's total width has to be less than the container's width for the justify-content property to have any effect.</h3>
                    <a href="#" class="btn">Read More</a>
                    </div>
                </div>
           
       
                <div class="postBox">
                    
                    <img src="post4.jpg" class="covered">
                    
                    <div class="textBx">
                    <h3> The grid's total width has to be less than the container's width for the justify-content property to have any effect.</h3>
                    <a href="#" class="btn">Read More</a>
                    </div>
                </div>
          
       
                <div class="postBox">
                   
                    <img src="post5.jpg" class="covered">
            
                <div class="textBx">
                    <h3> The grid's total width has to be less than the container's width for the justify-content property to have any effect.</h3>
                    <a href="#" class="btn">Read More</a>
                </div>
                </div>
          
        
                <div class="postBox" >
                   
                    <img src="post6.jpg" class="covered">
                    
                    <div class="textBx">
                    <h3> The grid's total width has to be less than the container's width for the justify-content property to have any effect.</h3>
                    <a href="#" class="btn">Read More</a>
                    </div>
                </div>
          
    </div>
</div>
        <div class="title">
            <a href="#" class="btn mtg60">Load More</a>
        </div>
     </section>


     <!--Contact Us-->
     <section class="Contact" id="Contact">
         <div class="title">
             <h2>Contact Us</h2>
             <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
         </div>
         <div class="contactForm">
             <div class="row">
                 <input type="text" name="" placeholder="First Name">
                 <input type="text" name="" placeholder="Last  Name">
             </div>
         </div>
         <div class="contactForm">
            <div class="row">
                <input type="text" name="" placeholder="Email Address">
                <input type="text" name="" placeholder="Mobile No">
            </div>
        </div>
        <div class="row2" style="margin: 0px; width: 258px; height: 90px";>
            <textarea  style="margin: 0px; width: 258px; height: 58px"; placeholder="Message"></textarea>
        </div>
        <div class="row2">
            <input type="submit" value="Send" class="btn">
        </div>
     </section>

     <!--Footer-->
     <footer>
         <a href="#" class="logo">My Blog</a>
         <ul class="footerMenu">
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About Us</a></li>
            <li><a href="#post">Posts</a></li>
            <li><a href="#Contact">Contact Us</a></li> 
         </ul>
         <p class="copyrightText">All rights reserved 2021</p>
     </footer>


        <script>
            const menuToggle= document.querySelector('.menuToggle');
            const navigation=document.querySelector('.navigation');
            menuToggle.onclick=function(){
                menuToggle.classList.toggle('active');
                navigation.classList.toggle('active');
            }
            window.addEventListener('scroll', function(){
                const header= document.querySelector('header');
                header.classList.toggle('sticky', window.scrollY>0)
            })

            function toggleMenu(){
                menuToggle.classList.remove('active');
                navigation.classList.toggle('active');
            }
        </script>
    </body>
</html>